#pragma once

#include "defines.hpp"
#include "core/clock/clock.hpp"
#include "core/input/input.hpp"
#include "core/event/event.hpp"
#include "camera/camera.hpp"
#include "resources/mesh/mesh.hpp"

int main(int argc, char** argv);

// TODO: temp
#include "resources/geometry/geometry.hpp"
// TODO: temp

namespace Engine {

    struct ApplicationSetup {
        std::string name;
        i32 width;
        i32 height;
        i32 start_x;
        i32 start_y;
    };

    struct ApplicationCommandLineArgs
	{
		int Count = 0;
		char** Args = nullptr;

		const char* operator[](int index) const
		{
			return Args[index];
		}
	};

    class ENGINE_API Application {
        public:
            static void CreateApplication();

            Application(ApplicationSetup setup = {"Unnamed", 800, 600, 100, 100}, ApplicationCommandLineArgs args = ApplicationCommandLineArgs());
            virtual ~Application() = default;

            ApplicationSetup& GetSetup() { return setup; };

            virtual b8 GameUpdate(f32 delta) = 0;
            virtual b8 GameInitialize() = 0;

            void SetSuspended (b8 suspended) { this->suspended = suspended; };
            b8 GetSuspended () { return suspended; };
            
            Camera* GetCamera();

            void SetReady(b8 value);
            b8 IsReady();
            void Run();
            void Shutdown();
            void Stop();

        protected:
            ApplicationSetup setup;

            b8 RegisterEvents();

            b8 onExit(EventType type, EventContext& context);
            b8 onKey(EventType type, EventContext& context);
            b8 onResize(EventType type, EventContext& context);
            b8 OnDebugEvent(EventType type, EventContext& context);
            b8 OnDebugEvent2(EventType type, EventContext& context);

            u32 GetFrameWidth();
            u32 GetFrameHeight();


        private:
            b8 running = false;
            b8 suspended = false;
            b8 is_ready = false;
            b8 rotate = false;

            Clock clock;

            std::vector<Mesh*> meshes;

            Geometry* test_geometry;
            Geometry* test_ui_geometry;
            u32 current_material = 3;
            
            f64 last_time;

            static Application* instance;
            friend int ::main(int argc, char** argv);
    };


    Application* CreateApplication(ApplicationCommandLineArgs args);
}